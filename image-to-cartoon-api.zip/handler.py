import requests
import base64
import os
import json
from PIL import Image
from comfy.cli import load_workflow, run_workflow

FACE_IMAGE_PATH = "/tmp/face.png"
CARTOON_IMAGE_PATH = "/tmp/cartoon.png"
WORKFLOW_FILE = "workflow.json"

def download_image(url, path):
    response = requests.get(url)
    if response.status_code == 200:
        with open(path, "wb") as f:
            f.write(response.content)
    else:
        raise Exception(f"Failed to download image from {url}")

def handler(event):
    inputs = event.get("input", {})
    face_url = inputs.get("face_image_url")
    cartoon_url = inputs.get("cartoon_image_url")

    if not face_url or not cartoon_url:
        return {"error": "Missing 'face_image_url' or 'cartoon_image_url'"}

    download_image(face_url, FACE_IMAGE_PATH)
    download_image(cartoon_url, CARTOON_IMAGE_PATH)

    with open(WORKFLOW_FILE, "r") as f:
        workflow = json.load(f)

    for node in workflow.values():
        if node["class_type"] == "LoadImage":
            title = node["_meta"]["title"].lower()
            if "real" in title:
                node["inputs"]["image"] = FACE_IMAGE_PATH
            elif "cartoon" in title:
                node["inputs"]["image"] = CARTOON_IMAGE_PATH

    result = run_workflow(workflow)

    output_images = result.get("images", [])
    if not output_images:
        return {"error": "No output image generated"}

    output_path = output_images[0]
    with open(output_path, "rb") as f:
        img_b64 = base64.b64encode(f.read()).decode("utf-8")

    return {
        "image_base64": img_b64,
        "message": "Cartoon personalized image generated successfully."
    }